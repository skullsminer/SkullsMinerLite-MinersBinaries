ccMiner release 8.21(KlausT-mod) mod r17 for Koto Sapling support Version 2
2019-01-11

This software is modified ccMiner release 8.21(KlausT-mod) mod r17 for Koto Sapling support.

Built by ������(Nanashi)
  BTC: 3NM7dNxUAJxLWeL2FAhtoGN6uZjqFKckfM
  MONA: P9jzrzq5BKASZim3F2ssq3Xdgme6EHNHDw

System requirements
  Windows 10 64bit
  NVIDIA graphic boards with CUDA 10.0

Operation checked graphic boards
  RTX 2080
  GTX 1060

Source code
  ccminer-KlausT-8.21-mod-r17-src.zip
  https://1drv.ms/u/s!Aud1FauQ46vHh255NYbLOB2bQlOt

  sapling.diff (ccminer-KlausT-8.21-mod-r17 patch for Koto Sapling)
  https://gist.github.com/wo01/75ecb9660f5848ab308f93ce6cd42921

  ccminer.cpp nonceptr fix
  https://askmona.org/11245#res_69

History
  Version 2 2019-01-11
    ccminer.cpp nonceptr fix.
  Version 1 2019-01-06
    First release.
