Z-ENEMY 2.6.3  From: Dk & Enemy (z-enemy)

IMPORTANT:
For maximum performance make sure you have latest drivers 
http://www.nvidia.com/Download/index.aspx

Changes: (test buid)
- Support 30x0 GPU
_____________________________________
First time or troubleshooting kawpow:
-   First time users - all ver. 2.02+ works on Cuda 9.x &Cuda 10.x and it is recommended to make sure you've updated your NVIDIA drivers. You can find drivers here: http://www.nvidia.com/Download/index.aspx ver., min  ver.398+++
-   Next important thing is intensity. We recommend intensity for start -19 or 20,(21 for 20x0) at first.
-   kawpow algo using +mem , but use no OC at first until you verify stability.. 
